#!/usr/bin/env  python

'''A series of specialized exceptions.
    I like to keep them in a seperate file to minimize clutter in more 'functional' modules.
'''

class InvalidNucStringException(Exception):
    '''signals that a string does not only contain nucleotide characters
        It inherits from the mother of all exceptions itself.
        No extra code is needed!
    '''


class InvalidDNAStringException(Exception):
    '''signals that a string does not only contain DNA characters
        It inherits from the mother of all exceptions itself.
        No extra code is needed!
    '''

class InvalidRNAStringException(Exception):
    '''signals that a string does not only contain RNA characters
        It inherits from the mother of all exceptions itself.
        No extra code is needed!
    '''
