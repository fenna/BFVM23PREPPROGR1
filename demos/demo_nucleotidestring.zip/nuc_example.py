#!/usr/bin/ env python

'''just a demo using nucleotidestrings and exceptions'''

from sys import argv
import nucleotidestrings as n


#a sloppy way to work with input, always validate input!
#sys.argv[0] contains the name of the script
dna = argv[1]
try:
    d = n.DNAString(dna)
    print(d)
except n.InvalidDNAStringException:
    try:
        d = n.NucleotideString(dna)

        print("Dear User, it appears that the string you gave as input contains characters other than 'a', 't', 'c' and 'g', making it impossible to create a DNAString. " \
            "However, it was possible to create a NucleotideString using this input. An object of this type is returned. You may consider using a RNAString for this input")
        print()
        print(d)
    except Exception as error:
        #all other exceptions
        print('Something is really wrong. Aborting with extreme prejudice!')

        #raise exception again to exit
        raise error
finally:
    print('\nThank you for using my code!')
