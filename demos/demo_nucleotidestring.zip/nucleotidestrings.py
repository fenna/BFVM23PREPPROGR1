#!/usr/bin/env  python

'''This module showcases possible solutions on how to model nucleotidestrings'''

import re

from nucstring_exceptions import InvalidNucStringException, InvalidDNAStringException, InvalidRNAStringException

class NucleotideString():
    '''A possible solution using encapsulation.  The fact that with inheritance it would inherit
         all properties and methods from String may be problematic. E.g. capitalize a DNA-string?
         Hence the choice for encapsulation.
    '''

    #Maps the complements for translation. Note that the reversed complement
    #always is a DNA sequence
    REV_MAP = str.maketrans({'a': 't', 't': 'a', 'u':'a', 'c': 'g', 'g': 'c'})

    #re pattern describing a string of 0 or more a, t, c, g, or u's
    #I made this a variable at class level to make inheritance easier
    #DNA consists of a, t, c and g while RNA contains u instead of t
    #Since this this is a generalized nucleotide string, it should accept both DNA and RNA
    #hence a, c, g, t and u
    VALID_NUCLEOTIDE_PATTERN = re.compile('[actgu]*', re.IGNORECASE)

    #a hack that makes it possible to write even less code when writing subclasses :)
    DEFAULT_EXCEPTION = InvalidNucStringException('Only a, c, t, g and u are valid nucleotides')

    @classmethod
    def is_a_valid_sequence(cls, nuc_string):
        '''validate if a string consists only of ATCGU.
            I made this a class method since it does not interact with any instance properties.
            The string which is checked is not yet set as a property!

            N.B that there is no check on mixed RNA-DNA hybrid sequences!
        '''
        return re.fullmatch(cls.VALID_NUCLEOTIDE_PATTERN, nuc_string)


    def __init__(self, nuc_string):
        '''this is called if a new instance is created'''

        #I like to initialize all properties for readability
        self._nuc_string = ''

        nuc_string = nuc_string.strip().lower()

        #use the setter below to set the sequence
        self.sequence = nuc_string

        #I could also calculate the reversed complement now and store its reversed complement
        #This property could then be accessed by e.g. <object>.reversed_complement
        #However, because there is no _ before the property name, everybody can assume
        #it is OK to change its value
        #
        #Other considerations are memory vs. performance
        #I chose not to store it now because I want to showcase alternatives later in the this code


    def get_rev_complement(self):
        '''returns the reverse complement of the string.
            Note that it would also have been possible to calculate this in __init__
            and store the result in an instance variable
        '''
        return self._nuc_string.translate(NucleotideString.REV_MAP)[::-1]


    @property
    def reversed_complement(self):
        '''a more pythonic way to do the same as in get_rev_complement().
            Note that this function allows you to retrieve the complement as if it were a variable
            and not a function (<object>.reversed_complement)

            Since no (public) setter is defined, everybody will understand that
            this property is read-ony
        '''
        return self._nuc_string.translate(NucleotideString.REV_MAP)[::-1]


    @property
    def sequence(self):
        '''returns the nucleotide string'''
        return self._nuc_string


    @sequence.setter
    def sequence(self, nuc_string):
        '''a setter for the sequence'''
        nuc_string = nuc_string.strip().lower()

        #note that the method accessess a method of it's class!
        if self.is_a_valid_sequence(nuc_string):
            self._nuc_string = nuc_string
        else:
            #most libraries are meant to be used by other scripts that will take care of the
            #interactions with the end user. Therefore they never print anything.
            #when someting unforeseen happens, raise an error
            #send a message to the front end script that invalid input has been recieved
            raise self.DEFAULT_EXCEPTION
        #raise InvalidNucStringException('Only a, c, t, g and u are valid nucleotides')

    #@sequence.deleter
    #def sequence(self):
    #'''if you want to be able to delete a property, include a deleter
    #   not needed in this case.'''
    #   del self.sequence

    def __str__(self):
        '''this function is called when you print an object of this class'''
        return "5'-" + self._nuc_string + "-3'"


class RNAString(NucleotideString):
    '''RNA is a form nucleic acid'''

    #only acgu are valid in a DNA string. Because I use inheritance (and spent some time thinking
    #before I started coding) these are the only line I have to change!
    VALID_NUCLEOTIDE_PATTERN = re.compile('[acgu]*', re.IGNORECASE)
    DEFAULT_EXCEPTION = InvalidRNAStringException('Only a, c, g and u are valid nucleotides in RNA')


class DNAString(NucleotideString):
    '''DNA is a form nucleic acid'''

    #only acgu are valid in a DNA string. Because I use inheritance (and spent some time thinking
    #before I started coding) these are the only line I have to change!
    VALID_NUCLEOTIDE_PATTERN = re.compile('[acgt]*', re.IGNORECASE)
    DEFAULT_EXCEPTION = InvalidDNAStringException('Only a, c, g and u are valid nucleotides in DNA')


    def __str__(self):
        '''just to show you an overloaded method (and DNA being double stranded)'''
        h_bridges = "-3'\n   " + len(self._nuc_string) * '|' + "\n3'-"

        return "5'-" + self._nuc_string + h_bridges + self.sequence.translate(self.REV_MAP) + "-5'"


if __name__ == '__main__':
    #I could add some code here which will NOT be executed when this module is imported
    print('Hello World!')
