'''command line interface for assignment week 3
Command line syntax:
    python week3b_arne.py "../Data/SampleAnnot.csv" "../Data/MicroarrayExpression.csv" "../Data/Probes.csv" 15
'''


#you could also use getopt, sys or an external library
import argparse

#import everything from week3a
from week3a_arne import *

def get_options():
    '''reads the options from the command line'''
    parser = argparse.ArgumentParser()
    parser.description = 'commandline utility to parse and process specific microarray data'

    #we need arguments for annotation data, expression data, gene data and a cut off value
    parser.add_argument('annotation_data', action = 'store', \
            help = 'file containing annotation data')
    parser.add_argument('expression_data', action = 'store', \
            help = 'file containing expression data')
    parser.add_argument('gene_data', action = 'store', \
            help = 'file containing gene data')
    parser.add_argument('cut_off', action = 'store', default = 15, type = float, \
            help = 'cut of value (default 15)')

    return parser.parse_args()

#I put the paths to files in CONSTANTS, so they are more seperate from the rest of the code
#and makes it easier to read
#ANNOTATIONS = '../Data/SampleAnnot.csv'
#EXPRESSION_DATA = '../Data/MicroarrayExpression.csv'
#GENE_DATA = '../Data/Probes.csv'

arguments = get_options()
print(arguments)

#try:
#gene_dict, lookup = process_gene_info(arguments.gene_data)
#process_expressions(arguments.expression_data, lookup, gene_dict)
#except IOError:
#    print('wrong file path!')
#else:
#    print(gene_dict['729'])
#    print(len(gene_dict))
#
#
gene_dict, lookup = process_gene_info(arguments.gene_data)
process_expressions(arguments.expression_data, lookup, gene_dict)
print(gene_dict['729'])
print(len(gene_dict))

#End of part 1

with open(arguments.annotation_data, encoding='us-ascii') as annotations:
    annotation_lines = [line.split(',') for line in annotations.readlines()]

#create a set with line id's containing LHM structures
#the function returns a list containing line numbers which is an
#iterable that can be used for the creation of a set
lhm_structure_lines = set(get_sample_ids(annotation_lines, '"LHM"'))

#the same for PHA
pha_structure_lines = set(get_sample_ids(annotation_lines, '"PHA"'))

#Tell Python that annotation_lines is not needed anymore so that it can reclaim the used memory
#if necessary
annotation_lines = None

#retrieve the probes

#read the expressions file and split the lines on comma's.
#The file is less than 1G so fits comfortably
#in the memory of the BIN computers and of my laptop so memeory should not be a problem
#and it is faster
#than retrieving every line separately
with open(arguments.expression_data, encoding = 'us-ascii') as ex_data:
    exp_lines = [line.split(',') for line in ex_data.readlines()]

lhm_probes = set()
for column in lhm_structure_lines:
    lhm_probes |= get_probes_by_column(exp_lines, column, arguments.cut_off)

pha_probes = set()
for column in pha_structure_lines:
    pha_probes |= get_probes_by_column(exp_lines, column, arguments.cut_off)

exp_lines = None


#shared between lhm and pha
print('Probes shared among regions lateral hypothalamic area, \
        mammillary region and posterior hypothalamic area')
print(lhm_probes & pha_probes)
print('\n')

print('Probes unique in lateral hypothalamic area, mammillary region')
print(lhm_probes - pha_probes)
print('\n')

print('Probes unique in posterior hypothalamic area')
print(pha_probes - lhm_probes)
print('\n')
