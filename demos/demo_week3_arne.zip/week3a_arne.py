#!/usr/bin/env python
'''Demo script for assignment week 2'''

from statistics import mean

def process_expression_line(line):
    '''processes a single line containing probe_id and its expression values seperated by comma's
        Input: string (a line as described)
        Output: a tuple containing probe_id and its average expression value
    '''
    probe_id, *values = line.split(',')

    #cast values to floats
    for position, value in enumerate(values):
        values[position] = float(value)
    return (probe_id, mean(values))


def process_expressions(expression_data, lookup, gene_dict):
    '''reads the expression data and calculates the average.
        It then looks up with which gene the probe is associated in GENE_DATA
        if the gene is not yet present in the relevant dictionary:
            it gets created and the probe and its average value get stored with it
        else:
            if the current probe has a higher average expression value
                it replaces the probe currently present in the gene
        Input:
            path to file containg expressoin data
            lookup dictionary
            dictionary with genes
        Output: -
        Preconditions: lookup and gene_dict exist
        Postconditions: genes are added to the global gene_dict

    '''
    with open(expression_data, encoding = 'us-ascii') as expressions:
        for line in expressions:
            probe_id, avg = process_expression_line(line)

            #get the id of the gene
            gene_id = lookup[probe_id]

            #add the probe to its gene
            gene_dict[gene_id][probe_id] = avg

            #if this probe has he highest expression value for this gene set highest to this value
            max_average_probe_id = gene_dict[gene_id]['highest']
            if avg > gene_dict[gene_id][max_average_probe_id]:
                gene_dict[gene_id]['highest'] = probe_id


def process_gene_info(gene_data):
    '''retrieves information from the input file and returns a
         dictionary containing one entry per gene
        each gene entry should contain a dictionary containing all its probes

        Input: file containing information about gene-probe associations
        Output: dictionary containing one entry per gene as described
                dictionary to efficiently look up to which gene a probe belongs

    '''
    #when you look at the header of Probes.csv, the probe id is stored in the first field,
    #the gene_ids are stored in the 3rd field
    #so I store these column numbers in local constants
    gene_id_field = 2
    probe_id_field = 0

    genes = {}
    probes_to_genes = {}

    with open(gene_data, encoding='us-ascii') as probe_data:
        for line in probe_data:
            #ignore header
            if line.startswith('probe_id'):
                pass
            else:
                #gene and probe id will be used as keys in dicts, so must be converted to strings
                probe_info = line.split(',')
                gene_id = str(probe_info[gene_id_field])
                probe_id = str(probe_info[probe_id_field])

                #add the gene if necessary. Also add an entry that will contain the id of
                #the probe with the highest avg. expression because we will need it later
                if gene_id not in genes:
                    genes[gene_id] = {'highest': probe_id}

                #add the probe to the gene in the genes dictionary,
                #its average value is as yet unknown so should be set to None
                #genes is a dict containing dicts so you have to use two keys :)
                # genes = {gene1: {probe1: None, probe2: None}, gene2: {probe100: None, ...}, ...}
                genes[gene_id][probe_id] = None

                #add entry to lookup dictionary
                probes_to_genes[probe_id] = gene_id
    return genes, probes_to_genes



##################################################################################################

def get_probes_by_column(expression_lines, column_id, cut_off = 15):
    '''looks for probes that are expressed more than a certain value in a list of lines
        taht consist of a probe id and its expression values all seperated by comma's
        Input: list of lists epresenting lines in MicroarrayExpreesions.csv
            integer with the column to be looked at
            a float containing the cut of value
        Output: a set of probe id's that have an expression value >= cut_off in the relevant column
    '''
    probe_ids = {line[0] for line in expression_lines if float(line[column_id]) > cut_off}
    return probe_ids


def get_sample_ids(annotation_lines, acronym):
    '''looks for structures in a list that represent annotation lines
        and returns a list containing the ids of these lines
        the reason to use a list as input and not read the file here is that reading costs a lot of
        time and for each structure the file would have to be read again
        Input: list with annotation lines
                the acronym of the structure of which the relevant lines must be returned
        Output: a list with line numbers
    '''
    #put the column number in a variable for readability
    structure_acronym = 4
    lines = [line_id for line_id, line in enumerate(annotation_lines) \
            if line[structure_acronym].startswith(acronym)]
    return lines




if __name__ == '__main__':
    #you could add some code here you want to execute if this module is executed and not imported
    print('Hello World!')
